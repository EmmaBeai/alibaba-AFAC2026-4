# Financial Long Document QA Agent

这是金融长文档问答比赛的最小可运行工程骨架。第一版目标不是追求复杂 Agent，而是先打通一条可复现主链：

1. 读取文档元数据和题目文件。
2. 将 PDF/TXT/MD 文档解析为文本并切分为 chunk。
3. 用本地词法检索定位候选证据。
4. 在正式答题阶段只调用 Qwen 系列 API。
5. 生成 `submission/answer.csv` 和 `submission/evidence.jsonl`。

## Directory

```text
data/
  documents.jsonl        # doc_id/path/title/domain 元数据
  questions.jsonl        # 题目文件，兼容 A 榜 doc_ids 和 B 榜无 doc_ids
  raw/                   # 原始 PDF/TXT/MD 文档
processed_data/
  docs.jsonl             # 解析后的全文
  chunks.jsonl           # 检索 chunk
agent/
  answering.py           # 单题作答主逻辑
  chunking.py            # 文本切分
  config.py              # 配置加载
  io_utils.py            # JSONL/CSV IO
  normalize.py           # 答案字母规范化
  prompts.py             # Qwen prompt
  qwen_client.py         # Qwen API 包装和 token 统计
  retrieval.py           # 第一版词法检索
  schema.py              # 数据结构
script/
  preprocess.py          # 文档解析和 chunk 构建
  run_answer.py          # 生成 answer.csv 和 evidence.jsonl
tests/
```

## Input Contract

`data/documents.jsonl` 每行一个文档：

```json
{"doc_id":"byd_2024_annual","path":"raw/byd_2024_annual.pdf","title":"比亚迪 2024 年年度报告","domain":"financial_reports"}
```

`data/questions.jsonl` 每行一道题：

```json
{"qid":"fin_a_001","domain":"financial_reports","split":"A","question":"...","options":{"A":"...","B":"...","C":"...","D":"..."},"answer_format":"multi","type":"财务指标对比分析","doc_ids":["byd_2024_annual","byd_2025_annual"]}
```

## Environment

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp config.example.json config.json
```

配置 Qwen API：

```bash
export DASHSCOPE_API_KEY="your-api-key"
```

默认使用 OpenAI-compatible 调用方式，`config.example.json` 里的 `base_url` 可按平台文档调整。

## Run

```bash
python -m script.preprocess
python -m script.preview_retrieval
python -m script.run_answer
```

输出：

```text
submission/answer.csv
submission/evidence.jsonl
```

接 Qwen API 前可以先运行 `preview_retrieval`，检查每道题的候选文档和 chunk 是否合理；这一步不调用模型。

`answer.csv` 第一行为 `summary`，其后每题一行，字段符合赛题提交格式：

```text
qid,answer,prompt_tokens,completion_tokens,total_tokens
```

## Competition Boundary

预处理阶段可以使用 PDF 解析、OCR、版面分析、表格恢复等工具，但这些工具只能用于把文档变成更可读的结构化输入。

正式答题阶段，包括文档定位、段落检索、证据判断、答案生成、自检和纠错，应只使用 Qwen 系列模型。当前第一版检索是本地词法检索，不调用其他模型，也不使用非 Qwen 向量或 rerank。

## Next Iterations

建议按这个顺序迭代：

1. 先用 A 榜 `doc_ids` 跑通闭环，确认答案格式和 token 统计不出错。
2. 替换 PDF 解析为 MinerU 或其他版面结构化结果，但不要把非 Qwen 摘要写入正式证据。
3. 强化检索：条款号、金额、日期、百分比、公司名、产品名加权。
4. 分领域 prompt：保险、监管、合同、财报、研报分别约束证据和计算方式。
5. 加二阶段 Qwen 自检，只对低置信题触发，控制 token。
