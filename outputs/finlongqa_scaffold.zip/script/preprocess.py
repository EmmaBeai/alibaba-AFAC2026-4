from __future__ import annotations

import argparse
from pathlib import Path

from agent.chunking import make_chunks, normalize_text
from agent.config import Config
from agent.io_utils import read_jsonl, write_jsonl
from agent.schema import DocumentMeta, ParsedDocument


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=None)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    cfg = Config.load(root, args.config)
    docs_meta_path = cfg.data_dir / "documents.jsonl"
    metas = [DocumentMeta.from_dict(row) for row in read_jsonl(docs_meta_path)]

    parsed_docs: list[dict[str, str]] = []
    all_chunks = []
    for meta in metas:
        source_path = cfg.data_dir / meta.path
        text = extract_text(source_path)
        doc = ParsedDocument(
            doc_id=meta.doc_id,
            title=meta.title,
            domain=meta.domain,
            text=normalize_text(text),
        )
        parsed_docs.append(
            {
                "doc_id": doc.doc_id,
                "title": doc.title,
                "domain": doc.domain,
                "text": doc.text,
            }
        )
        all_chunks.extend(chunk.to_dict() for chunk in make_chunks(doc))

    write_jsonl(cfg.processed_dir / "docs.jsonl", parsed_docs)
    write_jsonl(cfg.processed_dir / "chunks.jsonl", all_chunks)
    print(f"processed docs={len(parsed_docs)} chunks={len(all_chunks)}")


def extract_text(path: Path) -> str:
    if not path.exists():
        raise FileNotFoundError(path)
    suffix = path.suffix.lower()
    if suffix in {".txt", ".md"}:
        return path.read_text(encoding="utf-8")
    if suffix == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise RuntimeError("PDF parsing requires: pip install pypdf") from exc
        reader = PdfReader(str(path))
        return "\n\n".join(page.extract_text() or "" for page in reader.pages)
    raise ValueError(f"unsupported document type: {path}")


if __name__ == "__main__":
    main()

