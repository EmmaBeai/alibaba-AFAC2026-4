from __future__ import annotations

import argparse
from pathlib import Path

from agent.answering import answer_question
from agent.config import Config
from agent.io_utils import read_jsonl, write_answer_csv, write_jsonl
from agent.qwen_client import QwenClient
from agent.retrieval import LexicalRetriever
from agent.schema import Chunk, Question


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=None)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    cfg = Config.load(root, args.config)
    questions = [Question.from_dict(row) for row in read_jsonl(cfg.data_dir / "questions.jsonl")]
    chunks = [Chunk.from_dict(row) for row in read_jsonl(cfg.processed_dir / "chunks.jsonl")]
    retriever = LexicalRetriever(chunks)
    client = QwenClient(
        model=cfg.model,
        base_url=cfg.base_url,
        temperature=cfg.temperature,
    )

    answer_rows = []
    evidence_rows = []
    total_prompt = 0
    total_completion = 0

    for index, question in enumerate(questions, start=1):
        result = answer_question(
            question=question,
            retriever=retriever,
            client=client,
            top_k=cfg.top_k,
            candidate_docs=cfg.candidate_docs,
            max_context_chars=cfg.max_context_chars,
        )
        total_prompt += result.prompt_tokens
        total_completion += result.completion_tokens
        answer_rows.append(
            {
                "qid": result.qid,
                "answer": result.answer,
                "prompt_tokens": result.prompt_tokens,
                "completion_tokens": result.completion_tokens,
                "total_tokens": result.total_tokens,
            }
        )
        evidence_rows.append(result.evidence)
        print(f"[{index}/{len(questions)}] {result.qid} answer={result.answer} tokens={result.total_tokens}")

    summary = {
        "qid": "summary",
        "answer": "",
        "prompt_tokens": total_prompt,
        "completion_tokens": total_completion,
        "total_tokens": total_prompt + total_completion,
    }
    write_answer_csv(cfg.submission_dir / "answer.csv", [summary, *answer_rows])
    write_jsonl(cfg.submission_dir / "evidence.jsonl", evidence_rows)
    print(f"wrote {cfg.submission_dir / 'answer.csv'}")


if __name__ == "__main__":
    main()

