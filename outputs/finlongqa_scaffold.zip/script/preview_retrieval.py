from __future__ import annotations

import argparse
from pathlib import Path

from agent.config import Config
from agent.io_utils import read_jsonl, write_jsonl
from agent.retrieval import LexicalRetriever
from agent.schema import Chunk, Question


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=None)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    cfg = Config.load(root, args.config)
    questions = [Question.from_dict(row) for row in read_jsonl(cfg.data_dir / "questions.jsonl")]
    chunks = [Chunk.from_dict(row) for row in read_jsonl(cfg.processed_dir / "chunks.jsonl")]
    retriever = LexicalRetriever(chunks)

    rows = []
    for question in questions:
        allowed_doc_ids = set(question.doc_ids) if question.doc_ids else set(
            retriever.candidate_doc_ids(question, cfg.candidate_docs)
        )
        hits = retriever.search(question, top_k=cfg.top_k, allowed_doc_ids=allowed_doc_ids)
        rows.append(
            {
                "qid": question.qid,
                "candidate_doc_ids": sorted(allowed_doc_ids),
                "hits": [
                    {
                        "chunk_id": hit.chunk.chunk_id,
                        "doc_id": hit.chunk.doc_id,
                        "title": hit.chunk.title,
                        "score": round(hit.score, 4),
                        "text_preview": hit.chunk.text[:240],
                    }
                    for hit in hits
                ],
            }
        )
        print(f"{question.qid}: docs={sorted(allowed_doc_ids)} hits={len(hits)}")

    out_path = cfg.submission_dir / "retrieval_preview.jsonl"
    write_jsonl(out_path, rows)
    print(f"wrote {out_path}")


if __name__ == "__main__":
    main()

