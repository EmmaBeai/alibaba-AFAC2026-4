from __future__ import annotations

from agent.schema import Question


SYSTEM_PROMPT = """你是金融长文档问答 Agent。必须只依据给定证据作答。
任务是从题目给定选项中选择正确答案。
要求：
1. 不使用常识替代证据。
2. 逐项判断选项是否被证据支持。
3. 涉及金额、比例、期限、日期、例外条件时必须核对条件。
4. 最终只输出一个 JSON 对象，不要输出 Markdown。
JSON 字段：
answer: 字符串，单选/判断为一个字母，多选为按字母排序的多个字母。
confidence: high/medium/low。
reason: 简短说明。
evidence_chunk_ids: 使用到的 chunk_id 数组。
"""


def build_user_prompt(question: Question, evidence_blocks: list[str]) -> str:
    options = "\n".join(f"{letter}. {text}" for letter, text in sorted(question.options.items()))
    evidence = "\n\n".join(evidence_blocks)
    return f"""题目 ID：{question.qid}
领域：{question.domain}
题型：{question.answer_format}
能力标签：{question.qtype}

题干：
{question.question}

选项：
{options}

候选证据：
{evidence}

请基于候选证据完成判断，并严格输出 JSON。"""
