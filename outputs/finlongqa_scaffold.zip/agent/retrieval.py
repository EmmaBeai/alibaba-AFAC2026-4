from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass

from agent.schema import Chunk, Question


TOKEN_RE = re.compile(
    r"[A-Za-z0-9_.%/+-]+|[\u4e00-\u9fff]"
)


def tokenize(text: str) -> list[str]:
    return [m.group(0).lower() for m in TOKEN_RE.finditer(text)]


@dataclass(frozen=True)
class SearchHit:
    chunk: Chunk
    score: float


class LexicalRetriever:
    def __init__(self, chunks: list[Chunk]) -> None:
        if not chunks:
            raise ValueError("retriever needs at least one chunk")
        self.chunks = chunks
        self.doc_freq: dict[str, int] = defaultdict(int)
        self.term_freqs: list[Counter[str]] = []
        self.lengths: list[int] = []
        for chunk in chunks:
            tokens = tokenize(chunk.text)
            tf = Counter(tokens)
            self.term_freqs.append(tf)
            self.lengths.append(len(tokens))
            for token in tf:
                self.doc_freq[token] += 1
        self.avg_len = sum(self.lengths) / len(self.lengths)

    def search(
        self,
        question: Question,
        top_k: int,
        allowed_doc_ids: set[str] | None = None,
    ) -> list[SearchHit]:
        query = build_query_text(question)
        query_terms = Counter(tokenize(query))
        scores: list[SearchHit] = []
        for i, chunk in enumerate(self.chunks):
            if allowed_doc_ids is not None and chunk.doc_id not in allowed_doc_ids:
                continue
            score = self._bm25_score(query_terms, i)
            if question.domain and question.domain == chunk.domain:
                score *= 1.08
            if score > 0:
                scores.append(SearchHit(chunk=chunk, score=score))
        scores.sort(key=lambda hit: hit.score, reverse=True)
        return scores[:top_k]

    def candidate_doc_ids(self, question: Question, limit: int) -> list[str]:
        hits = self.search(question, top_k=max(limit * 4, limit))
        doc_scores: dict[str, float] = defaultdict(float)
        for hit in hits:
            doc_scores[hit.chunk.doc_id] += hit.score
        return [
            doc_id
            for doc_id, _ in sorted(doc_scores.items(), key=lambda item: item[1], reverse=True)[:limit]
        ]

    def _bm25_score(self, query_terms: Counter[str], index: int) -> float:
        k1 = 1.5
        b = 0.75
        tf = self.term_freqs[index]
        doc_len = self.lengths[index] or 1
        score = 0.0
        total_docs = len(self.chunks)
        for term, query_weight in query_terms.items():
            freq = tf.get(term, 0)
            if freq == 0:
                continue
            df = self.doc_freq.get(term, 0)
            idf = math.log(1 + (total_docs - df + 0.5) / (df + 0.5))
            denom = freq + k1 * (1 - b + b * doc_len / self.avg_len)
            score += query_weight * idf * (freq * (k1 + 1) / denom)
        return score


def build_query_text(question: Question) -> str:
    option_text = " ".join(f"{letter}. {text}" for letter, text in sorted(question.options.items()))
    return f"{question.domain} {question.qtype} {question.question} {option_text}"

