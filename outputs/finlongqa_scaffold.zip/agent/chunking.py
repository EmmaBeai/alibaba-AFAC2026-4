from __future__ import annotations

import re

from agent.schema import Chunk, ParsedDocument


def normalize_text(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def make_chunks(
    doc: ParsedDocument,
    chunk_chars: int = 1800,
    overlap_chars: int = 240,
) -> list[Chunk]:
    if chunk_chars <= overlap_chars:
        raise ValueError("chunk_chars must be greater than overlap_chars")
    text = normalize_text(doc.text)
    chunks: list[Chunk] = []
    start = 0
    index = 0
    while start < len(text):
        hard_end = min(len(text), start + chunk_chars)
        end = _prefer_boundary(text, start, hard_end)
        chunk_text = text[start:end].strip()
        if chunk_text:
            chunks.append(
                Chunk(
                    chunk_id=f"{doc.doc_id}::chunk_{index:04d}",
                    doc_id=doc.doc_id,
                    title=doc.title,
                    domain=doc.domain,
                    text=chunk_text,
                    start=start,
                    end=end,
                )
            )
            index += 1
        if end >= len(text):
            break
        start = max(0, end - overlap_chars)
    return chunks


def _prefer_boundary(text: str, start: int, hard_end: int) -> int:
    window = text[start:hard_end]
    for marker in ("\n\n", "\n", "。", "；", ";"):
        pos = window.rfind(marker)
        if pos >= max(400, len(window) // 2):
            return start + pos + len(marker)
    return hard_end

