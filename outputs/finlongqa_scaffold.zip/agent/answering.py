from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from agent.normalize import is_valid_answer, normalize_answer
from agent.prompts import SYSTEM_PROMPT, build_user_prompt
from agent.qwen_client import QwenClient, parse_json_object
from agent.retrieval import LexicalRetriever, SearchHit
from agent.schema import Question


@dataclass(frozen=True)
class AnswerResult:
    qid: str
    answer: str
    prompt_tokens: int
    completion_tokens: int
    evidence: dict[str, Any]

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens


def answer_question(
    question: Question,
    retriever: LexicalRetriever,
    client: QwenClient,
    top_k: int,
    candidate_docs: int,
    max_context_chars: int,
) -> AnswerResult:
    allowed_doc_ids = set(question.doc_ids) if question.doc_ids else None
    if allowed_doc_ids is None:
        allowed_doc_ids = set(retriever.candidate_doc_ids(question, candidate_docs))
    hits = retriever.search(question, top_k=top_k, allowed_doc_ids=allowed_doc_ids)
    if not hits:
        raise RuntimeError(f"question {question.qid} has no retrieved evidence")
    evidence_blocks = build_evidence_blocks(hits, max_context_chars=max_context_chars)
    llm_result = client.chat_json(SYSTEM_PROMPT, build_user_prompt(question, evidence_blocks))
    raw_obj = parse_json_object(llm_result.content)
    answer = normalize_answer(str(raw_obj.get("answer", "")), question.answer_format)
    if not is_valid_answer(answer, question.answer_format):
        answer = ""
    return AnswerResult(
        qid=question.qid,
        answer=answer,
        prompt_tokens=llm_result.prompt_tokens,
        completion_tokens=llm_result.completion_tokens,
        evidence={
            "qid": question.qid,
            "answer": answer,
            "raw_response": raw_obj,
            "candidate_doc_ids": sorted(allowed_doc_ids),
            "hits": [
                {
                    "chunk_id": hit.chunk.chunk_id,
                    "doc_id": hit.chunk.doc_id,
                    "title": hit.chunk.title,
                    "score": round(hit.score, 4),
                    "start": hit.chunk.start,
                    "end": hit.chunk.end,
                }
                for hit in hits
            ],
        },
    )


def build_evidence_blocks(hits: list[SearchHit], max_context_chars: int) -> list[str]:
    blocks: list[str] = []
    used_chars = 0
    for hit in hits:
        header = (
            f"[chunk_id={hit.chunk.chunk_id} doc_id={hit.chunk.doc_id} "
            f"title={hit.chunk.title} score={hit.score:.4f}]"
        )
        block = f"{header}\n{hit.chunk.text}"
        if used_chars + len(block) > max_context_chars:
            remain = max_context_chars - used_chars
            if remain > 500:
                blocks.append(block[:remain])
            break
        blocks.append(block)
        used_chars += len(block)
    return blocks
