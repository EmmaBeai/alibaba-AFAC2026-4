from __future__ import annotations

import re


VALID_LETTERS = set("ABCD")


def normalize_answer(raw: str, answer_format: str) -> str:
    letters = [x for x in re.findall(r"[A-D]", raw.upper()) if x in VALID_LETTERS]
    if answer_format in {"mcq", "tf"}:
        return letters[0] if letters else ""
    if answer_format == "multi":
        return "".join(sorted(set(letters)))
    raise ValueError(f"invalid answer_format: {answer_format}")


def is_valid_answer(answer: str, answer_format: str) -> bool:
    if answer_format in {"mcq", "tf"}:
        return answer in VALID_LETTERS
    if answer_format == "multi":
        return bool(answer) and answer == "".join(sorted(set(answer))) and set(answer) <= VALID_LETTERS
    return False

