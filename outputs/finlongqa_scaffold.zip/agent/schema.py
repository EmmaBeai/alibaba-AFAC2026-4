from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class DocumentMeta:
    doc_id: str
    path: str
    title: str = ""
    domain: str = ""

    @classmethod
    def from_dict(cls, row: dict[str, Any]) -> "DocumentMeta":
        doc_id = str(row.get("doc_id", "")).strip()
        path = str(row.get("path", "")).strip()
        if not doc_id:
            raise ValueError("document row missing doc_id")
        if not path:
            raise ValueError(f"document {doc_id} missing path")
        return cls(
            doc_id=doc_id,
            path=path,
            title=str(row.get("title", "")).strip(),
            domain=str(row.get("domain", "")).strip(),
        )


@dataclass(frozen=True)
class Question:
    qid: str
    domain: str
    split: str
    question: str
    options: dict[str, str]
    answer_format: str
    qtype: str = ""
    doc_ids: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, row: dict[str, Any]) -> "Question":
        qid = str(row.get("qid", "")).strip()
        question = str(row.get("question", "")).strip()
        answer_format = str(row.get("answer_format", "")).strip()
        options_raw = row.get("options") or {}
        options = {str(k).strip().upper(): str(v).strip() for k, v in options_raw.items()}
        if not qid:
            raise ValueError("question row missing qid")
        if not question:
            raise ValueError(f"question {qid} missing question")
        if answer_format not in {"mcq", "multi", "tf"}:
            raise ValueError(f"question {qid} has invalid answer_format: {answer_format}")
        required_letters = "AB" if answer_format == "tf" else "ABCD"
        missing = [letter for letter in required_letters if letter not in options]
        if missing:
            raise ValueError(f"question {qid} missing options: {missing}")
        doc_ids = tuple(str(x).strip() for x in row.get("doc_ids") or () if str(x).strip())
        return cls(
            qid=qid,
            domain=str(row.get("domain", "")).strip(),
            split=str(row.get("split", "")).strip(),
            question=question,
            options=options,
            answer_format=answer_format,
            qtype=str(row.get("type", "")).strip(),
            doc_ids=doc_ids,
        )


@dataclass(frozen=True)
class ParsedDocument:
    doc_id: str
    title: str
    domain: str
    text: str


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    doc_id: str
    title: str
    domain: str
    text: str
    start: int
    end: int

    @classmethod
    def from_dict(cls, row: dict[str, Any]) -> "Chunk":
        return cls(
            chunk_id=str(row["chunk_id"]),
            doc_id=str(row["doc_id"]),
            title=str(row.get("title", "")),
            domain=str(row.get("domain", "")),
            text=str(row["text"]),
            start=int(row.get("start", 0)),
            end=int(row.get("end", 0)),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "chunk_id": self.chunk_id,
            "doc_id": self.doc_id,
            "title": self.title,
            "domain": self.domain,
            "text": self.text,
            "start": self.start,
            "end": self.end,
        }
