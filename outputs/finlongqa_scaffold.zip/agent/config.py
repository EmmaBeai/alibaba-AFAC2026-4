from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class Config:
    model: str
    base_url: str
    temperature: float
    max_context_chars: int
    top_k: int
    candidate_docs: int
    data_dir: Path
    processed_dir: Path
    submission_dir: Path

    @classmethod
    def load(cls, root: Path, config_path: Path | None = None) -> "Config":
        path = config_path or root / "config.json"
        if not path.exists():
            path = root / "config.example.json"
        with path.open("r", encoding="utf-8") as f:
            raw: dict[str, Any] = json.load(f)
        return cls(
            model=str(raw["model"]),
            base_url=str(raw["base_url"]),
            temperature=float(raw.get("temperature", 0)),
            max_context_chars=int(raw.get("max_context_chars", 18000)),
            top_k=int(raw.get("top_k", 8)),
            candidate_docs=int(raw.get("candidate_docs", 5)),
            data_dir=root / str(raw.get("data_dir", "data")),
            processed_dir=root / str(raw.get("processed_dir", "processed_data")),
            submission_dir=root / str(raw.get("submission_dir", "submission")),
        )

